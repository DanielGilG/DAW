package pruebaExamen.entity;

public enum State {
    PENDING,
    COMPLETED
}
