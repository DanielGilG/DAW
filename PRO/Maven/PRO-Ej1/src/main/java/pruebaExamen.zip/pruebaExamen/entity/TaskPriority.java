package pruebaExamen.entity;

public enum TaskPriority {
    LOW,
    MEDIUM,
    HIGH
}
