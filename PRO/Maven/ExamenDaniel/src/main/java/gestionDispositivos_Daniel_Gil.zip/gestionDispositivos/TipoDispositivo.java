package gestionDispositivos;

public enum TipoDispositivo {
    PORTATIL,
    SOBREMESA,
    TABLET;
}