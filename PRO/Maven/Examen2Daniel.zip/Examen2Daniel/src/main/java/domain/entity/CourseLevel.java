package domain.entity;

public enum CourseLevel {
    BEGGINER,
    INTERMEDIATE,
    ADVANCED
}
